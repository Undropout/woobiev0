// tier2.js
import { db, storage } from '../shared/firebase-config.js';
import { ref, set, get } from 'firebase/database';
import { ref as sRef, uploadBytes, getDownloadURL } from 'firebase/storage';
import { handleImage, setupColorButtons, updateCanvas } from './image-editor.js';

let username = localStorage.getItem('woobieUsername');
let matchID = localStorage.getItem('woobieMatchID');
let answers = [];

const questions = [
  'What’s a moment in your life that changed the way you see the world?',
  'How do you show someone you care about them?',
  'What’s something people often misunderstand about you?',
  'When do you feel most like yourself?',
  'What’s one thing you wish more people asked you about?',
  'What makes you feel seen or understood?',
  'What’s a belief you held strongly that changed over time?',
  'What’s one thing you never get tired of talking about?',
  'When have you felt the most brave?',
  'What do you wish someone had told you earlier in life?',
  'What kind of people do you feel safest around?',
  'What’s something you’ve forgiven yourself for?'
];

function updateQuestion(index) {
  document.getElementById('question-number').textContent = `Question ${index + 1} of ${questions.length}`;
  document.getElementById('question-text').textContent = questions[index];
  document.getElementById('answer').value = answers[index] || '';
}

function saveProgress() {
  localStorage.setItem('tier2Answers', JSON.stringify(answers));
}

async function submitAnswers() {
  const answerRef = ref(db, `matches/${matchID}/tier2/${username}`);
  await set(answerRef, { answers, timestamp: Date.now() });
  checkIfBothFinished();
}

async function checkIfBothFinished() {
  const snapshot = await get(ref(db, `matches/${matchID}/tier2`));
  const all = snapshot.val() || {};
  if (Object.keys(all).length >= 2) {
    showReview(all);
  } else {
    document.getElementById('question-block').style.display = 'none';
    document.getElementById('completion-message').style.display = 'block';
  }
}

function showReview(data) {
  const other = Object.keys(data).find(id => id !== username);
  const mine = data[username].answers;
  const theirs = data[other].answers;
  const container = document.getElementById('review');
  container.innerHTML = '<h2>Review Tier 2</h2>';
  questions.forEach((q, i) => {
    container.innerHTML += `
      <div class="qa-pair">
        <p><strong>Q${i+1}:</strong> ${q}</p>
        <p><strong>You:</strong> ${mine[i] || ''}</p>
        <p><strong>Match:</strong> ${theirs[i] || ''}</p>
        <hr>
      </div>
    `;
  });
  container.innerHTML += `
    <h3>Choose Your Reward</h3>
    <textarea id="tier2-text" placeholder="Send a short message (250 words max)"></textarea>
    <input type="file" id="audio-upload" accept="audio/*" />
    <input type="file" id="image-upload" accept="image/*" />
    <div id="image-adjust-wrapper" style="display:none;">
      <label>Alt text:</label>
      <input type="text" id="image-alt" maxlength="140" />
      <canvas id="chat-preview-canvas" width="128" height="128"></canvas>
      <div id="color-palette">
        <button class="color-btn" data-color="#33ff33">Green</button>
        <button class="color-btn" data-color="#ff66ff">Pink</button>
        <button class="color-btn" data-color="#00ffff">Cyan</button>
        <button class="color-btn" data-color="#ff9900">Amber</button>
      </div>
      <label for="chat-threshold">Threshold:</label>
      <input type="range" id="chat-threshold" min="0" max="255" value="128">
      <label for="chat-contrast">Contrast:</label>
      <input type="range" id="chat-contrast" min="-100" max="100" value="0">
    </div>
    <button id="send-reward" class="woobie-button">Send Reward</button>
    <h3>Would you like to continue?</h3>
    <button id="vote-yes" class="woobie-button">👍 Yes</button>
    <button id="vote-no" class="woobie-button">👎 No thanks</button>
    <p id="vote-waiting" style="display:none;">Waiting for your match's vote...</p>
  `;

  document.getElementById('send-reward').onclick = handleReward;
  document.getElementById('vote-yes').onclick = () => handleVote(true);
  document.getElementById('vote-no').onclick = () => handleVote(false);

  const imageUpload = document.getElementById('image-upload');
  imageUpload.onchange = e => {
    const file = e.target.files[0];
    if (file) {
      document.getElementById('image-adjust-wrapper').style.display = 'block';
      handleImage(file);
    }
  };
  setupColorButtons();
  document.getElementById('chat-threshold').oninput = updateCanvas;
  document.getElementById('chat-contrast').oninput = updateCanvas;
}

async function handleReward() {
  const text = document.getElementById('tier2-text').value.trim();
  const audioFile = document.getElementById('audio-upload').files[0];
  const alt = document.getElementById('image-alt').value.trim();
  const uploads = [];
  let audioURL = null;
  let imageURL = null;

  if (audioFile) {
    const audioRef = sRef(storage, `${matchID}/${username}/tier2-audio.webm`);
    uploads.push(uploadBytes(audioRef, audioFile).then(() => getDownloadURL(audioRef).then(url => audioURL = url)));
  }

  if (document.getElementById('chat-preview-canvas').toBlob) {
    const canvas = document.getElementById('chat-preview-canvas');
    const imageRef = sRef(storage, `${matchID}/${username}/tier2-image.png`);
    const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
    uploads.push(uploadBytes(imageRef, blob).then(() => getDownloadURL(imageRef).then(url => imageURL = url)));
  }

  await Promise.all(uploads);
  await set(ref(db, `matches/${matchID}/tier2Rewards/${username}`), {
    text,
    alt,
    imageURL,
    audioURL,
    timestamp: Date.now()
  });
  alert("Reward submitted!");
}

async function handleVote(vote) {
  await set(ref(db, `matches/${matchID}/tier2Votes/${username}`), vote);
  document.getElementById('vote-yes').style.display = 'none';
  document.getElementById('vote-no').style.display = 'none';
  document.getElementById('vote-waiting').style.display = 'block';
  waitForMutualVote();
}

async function waitForMutualVote() {
  const snapshot = await get(ref(db, `matches/${matchID}/tier2Votes`));
  const votes = snapshot.val() || {};
  if (Object.keys(votes).length >= 2) {
    if (Object.values(votes).every(v => v === true)) {
      window.location.href = './reveal.html';
    } else {
      document.getElementById('review').innerHTML = '<h2>Unfortunately, your match wasn\'t ready to continue. 😔</h2>';
    }
  } else {
    setTimeout(waitForMutualVote, 4000);
  }
}

const stored = JSON.parse(localStorage.getItem('tier2Answers') || '[]');
answers = stored;
let idx = answers.length || 0;

if (idx >= questions.length) {
  submitAnswers();
} else {
  updateQuestion(idx);

  document.getElementById('submit-btn').onclick = () => {
    const input = document.getElementById('answer').value.trim();
    if (!input) return;
    answers[idx] = input;
    saveProgress();
    idx++;

    if (idx < questions.length) {
      updateQuestion(idx);
    } else {
      document.getElementById('question-block').style.display = 'none';
      document.getElementById('completion-message').style.display = 'block';
      submitAnswers();
    }
  };
}
